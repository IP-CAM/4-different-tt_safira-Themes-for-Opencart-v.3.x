<?php
$_['heading_title'] 	=  'Temas de vales';
$_['text_success'] 	=  'Éxito: ¡Has modificado los temas de cupones!';
$_['text_list'] 	=  'Lista de temas de vales';
$_['text_add'] 	=  'Add Voucher Theme';
$_['text_edit'] 	=  'Tema Editar Bonos';
$_['column_name'] 	=  'Nombre del Tema del Vale';
$_['column_action'] 	=  'Acción';
$_['entry_name'] 	=  'Nombre del Tema del Vale';
$_['entry_description'] 	=  'Tema del vale Descripción';
$_['entry_image'] 	=  'Imagen';
$_['error_permission'] 	=  'Advertencia: ¡No tienes permiso para modificar temas de cupones!';
$_['error_name'] 	=  'Voucher Theme El nombre debe tener entre 3 y 32 caracteres.';
$_['error_image'] 	=  'Imagen necesaria!';
$_['error_voucher'] 	=  'Advertencia: este tema de cupones no se puede eliminar ya que está asignado a %s vouchers!';
