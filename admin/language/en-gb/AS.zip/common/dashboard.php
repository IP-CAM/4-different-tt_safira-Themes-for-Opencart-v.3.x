<?php
$_['heading_title'] 	=  'Tablero';
$_['error_install'] 	=  'Advertencia: La carpeta de instalación todavía existe y debe eliminarse por razones de seguridad.';
