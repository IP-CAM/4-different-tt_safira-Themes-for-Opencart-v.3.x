<?php
$_['text_footer'] 	=  '<a href=\"http://www.opencart.com\"> OpenCart </a> & copy; 2009-2017 Todos los derechos reservados.';
$_['text_version'] 	=  'Versión %s';
