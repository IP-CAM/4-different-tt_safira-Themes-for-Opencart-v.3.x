<?php
$_['heading_title'] 	=  'Configuración del desarrollador';
$_['text_success'] 	=  'Éxito: ¡Ha modificado la configuración del desarrollador!';
$_['text_theme'] 	=  'tema';
$_['text_sass'] 	=  'HABLAR CON DESCARO A';
$_['text_cache'] 	=  'Éxito: ¡Has eliminado la caché %s!';
$_['column_component'] 	=  'Componente';
$_['column_action'] 	=  'Acción';
$_['entry_theme'] 	=  'Tema';
$_['entry_sass'] 	=  'HABLAR CON DESCARO A';
$_['entry_cache'] 	=  'Cache';
$_['button_on'] 	=  'En';
$_['button_off'] 	=  'Apagado';
$_['error_permission'] 	=  'Advertencia: ¡No tiene permiso para modificar la configuración del programador!';
