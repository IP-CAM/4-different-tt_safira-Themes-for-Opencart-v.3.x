<?php
$_['heading_title'] 	=  'Administración';
$_['text_heading'] 	=  'Administración';
$_['text_login'] 	=  'Introduce tus datos de acceso.';
$_['text_forgotten'] 	=  'Contraseña olvidada';
$_['entry_username'] 	=  'Nombre de usuario';
$_['entry_password'] 	=  'Contraseña';
$_['button_login'] 	=  'Iniciar sesión';
$_['error_login'] 	=  'No hay coincidencia con nombre de usuario y / o contraseña.';
$_['error_token'] 	=  'Sesión de símbolo no válida. Inicie sesión nuevamente.';
