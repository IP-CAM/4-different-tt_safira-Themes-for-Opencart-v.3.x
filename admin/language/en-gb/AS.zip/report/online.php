<?php
$_['heading_title'] 	=  'Informe en Línea';
$_['text_extension'] 	=  'Extensiones';
$_['text_success'] 	=  'Éxito: ¡Usted ha modificado el informe en línea de sus clientes!';
$_['text_list'] 	=  'Lista en línea';
$_['text_filter'] 	=  'Filtrar';
$_['text_guest'] 	=  'Huésped';
$_['column_ip'] 	=  'IP';
$_['column_customer'] 	=  'Cliente';
$_['column_url'] 	=  'Última página visitada';
$_['column_referer'] 	=  'Referente';
$_['column_date_added'] 	=  'Último clic';
$_['column_action'] 	=  'Acción';
$_['entry_ip'] 	=  'IP';
$_['entry_customer'] 	=  'Cliente';
$_['entry_status'] 	=  'Estado';
$_['entry_sort_order'] 	=  'Orden de Clasificación';
$_['error_permission'] 	=  'Advertencia: ¡No tiene permiso para modificar el informe en línea de los clientes!';
