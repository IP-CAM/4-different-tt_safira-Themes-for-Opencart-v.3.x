<?php
$_['heading_title'] 	=  'Estadística';
$_['text_success'] 	=  'Éxito: ¡Usted ha modificado las estadísticas!';
$_['text_list'] 	=  'Lista de estadísticas';
$_['text_order_sale'] 	=  'Pedidos de Ventas';
$_['text_order_processing'] 	=  'Procesamiento de pedidos';
$_['text_order_complete'] 	=  'Órdenes completadas';
$_['text_order_other'] 	=  'Pedidos Otros';
$_['text_returns'] 	=  'Devoluciones';
$_['text_customer'] 	=  'Clientes que esperan aprobación';
$_['text_affiliate'] 	=  'Afiliados en espera de aprobación';
$_['text_product'] 	=  'Productos sin stock';
$_['text_review'] 	=  'Revisiones pendientes';
$_['column_name'] 	=  'Nombre de la estadística';
$_['column_value'] 	=  'Valor';
$_['column_action'] 	=  'Acción';
$_['error_permission'] 	=  'Advertencia: ¡No tiene permiso para modificar las estadísticas!';
