<?php
$_['heading_title'] 	=  'Editor de temas';
$_['text_success'] 	=  'Éxito: ¡Has modificado tus temas!';
$_['text_edit'] 	=  'Editar Tema';
$_['text_store'] 	=  'Elija su tienda';
$_['text_template'] 	=  'Elija una plantilla';
$_['text_default'] 	=  'Defecto';
$_['text_history'] 	=  'Historia del Tema';
$_['text_twig'] 	=  'El editor del tema utiliza el lenguaje de plantilla Twig. Puede leer acerca de la <a href=\"http://twig.sensiolabs.org/documentation\" target=\"_blank\" class=\"alert-link\"> sintaxis Twig aquí </a>.';
$_['column_store'] 	=  'Almacenar';
$_['column_route'] 	=  'Ruta';
$_['column_theme'] 	=  'Tema';
$_['column_date_added'] 	=  'Fecha Agregada';
$_['column_action'] 	=  'Acción';
$_['error_permission'] 	=  'Advertencia: ¡No tienes permiso para modificar el editor de temas!';
$_['error_twig'] 	=  'Advertencia: ¡Sólo puede guardar archivos .twig!';
