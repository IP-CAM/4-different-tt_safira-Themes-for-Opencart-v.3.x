<?php
$_['heading_title'] 	=  'Informes';
$_['text_success'] 	=  'Éxito: ¡Usted ha modificado los informes!';
$_['text_list'] 	=  'Lista de informes';
$_['text_type'] 	=  'Elija el tipo de informe';
$_['text_filter'] 	=  'Filtrar';
