<?php
$_['heading_title']             = '<b style="color: #eb5202;"><i><i class="t fa fa-twitter"></i> Plaza Tweet</i></b>';
$_['page_title']                = 'Plaza Tweet';

// Text
$_['text_extension']            = 'Extensions';
$_['text_success']              = 'Success: You have modified this module!';
$_['text_edit']                 = 'Edit Plaza Tweet';

// Entry
$_['entry_id']                  = 'Username';
$_['entry_status']              = 'Status';
$_['entry_limit']               = 'Limit';
$_['entry_show_time']           = 'Show Time';
$_['entry_consumer_key']        = 'Consumer Key';
$_['entry_consumer_secret']     = 'Consumer Secret';
$_['entry_access_token']        = 'Access Token';
$_['entry_access_token_secret'] = 'Access Token Secret';

// Error
$_['error_permission']          = 'Warning: You do not have permission to modify this module!';
$_['error_id'] 			        = "Twitter Username required!";