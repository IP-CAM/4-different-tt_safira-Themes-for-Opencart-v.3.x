<?php
$_['heading_title'] 	=  'OpenCart';
$_['text_profile'] 	=  'Tu perfil';
$_['text_store'] 	=  'Tiendas';
$_['text_help'] 	=  'Ayuda';
$_['text_homepage'] 	=  'Página de OpenCart';
$_['text_support'] 	=  'Foro de soporte';
$_['text_documentation'] 	=  'Documentación';
$_['text_logout'] 	=  'Cerrar sesión';
