<?php
$_['heading_title'] 	=  '¡Notificación de seguridad importante!';
$_['text_success'] 	=  'Éxito: ¡Has modificado la carpeta de almacenamiento!';
$_['text_admin'] 	=  'Editar admin / config.php y cambiar';
$_['text_security'] 	=  'Es muy importante que mueva el directorio de almacenamiento fuera del directorio web (por ejemplo, public_html, www o htdocs).';
$_['text_choose'] 	=  'Elija cómo mover el directorio de almacenamiento';
$_['text_automatic'] 	=  'Mover automáticamente';
$_['text_manual'] 	=  'Mover manualmente';
$_['text_move'] 	=  'Movimiento';
$_['text_to'] 	=  'a';
$_['text_config'] 	=  'Editar el cambio config.php';
$_['button_move'] 	=  'Movimiento';
$_['button_manual'] 	=  'Manual';
$_['error_permission'] 	=  'Advertencia: ¡No tiene permiso para modificar el directorio de almacenamiento!';
$_['error_path'] 	=  'Advertencia: ¡Ruta no válida!';
$_['error_directory'] 	=  'Advertencia: ¡Directorio no válido!';
$_['error_exists'] 	=  'Advertencia: ¡El directorio ya existe!';
$_['error_writable'] 	=  'Advertencia: config.php y admin / config.php necesitan ser escritos!';
