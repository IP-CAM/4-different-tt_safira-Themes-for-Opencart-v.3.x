<?php
$_['heading_title'] 	=  'Grupos de atributos';
$_['text_success'] 	=  'Éxito: ¡Has modificado los grupos de atributos!';
$_['text_list'] 	=  'Lista de grupos de atributos';
$_['text_add'] 	=  'Agregar grupo de atributos';
$_['text_edit'] 	=  'Editar grupo de atributos';
$_['column_name'] 	=  'Nombre del grupo de atributos';
$_['column_sort_order'] 	=  'Orden de Clasificación';
$_['column_action'] 	=  'Acción';
$_['entry_name'] 	=  'Nombre del grupo de atributos';
$_['entry_sort_order'] 	=  'Orden de Clasificación';
$_['error_permission'] 	=  'Advertencia: ¡No tiene permiso para modificar grupos de atributos!';
$_['error_name'] 	=  'El nombre del grupo de atributos debe tener entre 1 y 64 caracteres.';
$_['error_attribute'] 	=  'Advertencia: este grupo de atributos no se puede eliminar ya que está asignado a atributos %s.';
$_['error_product'] 	=  'Advertencia: ¡Este grupo de atributos no se puede eliminar ya que está asignado actualmente a %s products!';
