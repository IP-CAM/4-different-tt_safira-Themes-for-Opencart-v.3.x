<?php
$_['text_yes']          = 'Yes';
$_['text_no']           = 'No';
$_['entry_rotate']      = 'Rotate Image';