<?php
$_['heading_title'] 	=  'Filtros';
$_['text_success'] 	=  'Éxito: ¡Tienes filtros modificados!';
$_['text_list'] 	=  'Lista de filtros';
$_['text_add'] 	=  'Añadir filtro';
$_['text_edit'] 	=  'Editar filtro';
$_['text_group'] 	=  'Grupo de filtros';
$_['text_value'] 	=  'Valores de filtro';
$_['column_group'] 	=  'Grupo de filtros';
$_['column_sort_order'] 	=  'Orden de Clasificación';
$_['column_action'] 	=  'Acción';
$_['entry_group'] 	=  'Nombre del grupo de filtros';
$_['entry_name'] 	=  'Nombre del filtro';
$_['entry_sort_order'] 	=  'Orden de Clasificación';
$_['error_permission'] 	=  'Advertencia: ¡No tiene permiso para modificar los filtros!';
$_['error_group'] 	=  '¡El nombre del grupo de filtros debe tener entre 1 y 64 caracteres!';
$_['error_name'] 	=  'El nombre del filtro debe tener entre 1 y 64 caracteres.';
