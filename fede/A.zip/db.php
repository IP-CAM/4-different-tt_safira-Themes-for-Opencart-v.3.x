<?php
define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'gruposem_activad');
define('DB_PASSWORD', 'fKMUm6hUw$T^');
define('DB_DATABASE', 'gruposem_logisem_syssem_logicap');
$connection = mysqli_connect(DB_SERVER,DB_USERNAME,DB_PASSWORD,DB_DATABASE);
?>