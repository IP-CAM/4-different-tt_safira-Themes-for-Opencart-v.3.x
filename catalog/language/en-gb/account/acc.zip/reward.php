<?php
$_['heading_title'] 	=  'Tus puntos de recompensa';
$_['column_date_added'] 	=  'Fecha Agregada';
$_['column_description'] 	=  'Descripción';
$_['column_points'] 	=  'Puntos';
$_['text_account'] 	=  'Cuenta';
$_['text_reward'] 	=  'Puntos de recompensa';
$_['text_total'] 	=  'Su número total de puntos de recompensa es:';
$_['text_empty'] 	=  '¡No tienes puntos de recompensa!';
