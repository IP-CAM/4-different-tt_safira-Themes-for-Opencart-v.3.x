<?php
$_['heading_title'] 	=  'Mi lista de deseos';
$_['text_account'] 	=  'Cuenta';
$_['text_instock'] 	=  'En stock';
$_['text_wishlist'] 	=  'Listas de deseos)';
$_['text_login'] 	=  'Debe <a href="%s"> iniciar sesión </a> o <a href="%s"> crear una cuenta </a> para guardar <a href="%s"> %s </a> A su <a href="%s"> lista de deseos </a>!';
$_['text_success'] 	=  'Éxito: ha añadido <a href="%s"> %s </a> a su <a href="%s"> lista de deseos </a>!';
$_['text_remove'] 	=  'Éxito: ¡Has modificado tu lista de deseos!';
$_['text_empty'] 	=  'Tu lista de deseos Esta vacía.';
$_['column_image'] 	=  'Imagen';
$_['column_name'] 	=  'nombre del producto';
$_['column_model'] 	=  'Modelo';
$_['column_stock'] 	=  'Valores';
$_['column_price'] 	=  'Precio unitario';
$_['column_action'] 	=  'Acción';
