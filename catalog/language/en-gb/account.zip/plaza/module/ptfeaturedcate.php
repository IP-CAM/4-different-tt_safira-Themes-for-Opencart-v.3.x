<?php
$_['title'] = "Categorías Destacadas";
$_['text_products'] = "productos";