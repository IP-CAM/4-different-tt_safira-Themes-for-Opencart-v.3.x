<?php
$_['module_product_title'] = "Productos";
$_['text_empty'] = "No hay producto";
$_['text_availabe'] = "disponible:";
$_['text_sold'] = "Vendido:";
$_['text_viewmore'] = "ver detalles";