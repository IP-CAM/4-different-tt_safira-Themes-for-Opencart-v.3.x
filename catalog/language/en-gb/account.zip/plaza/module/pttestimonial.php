<?php
$_['title']  = 'Clientes';
$_['text_module_testimonial']  = 'Lo que ellos dicen';
$_['text_empty']     = 'Sin testimonios ahora.';