<?php
// Text
$_['text_placeholder_search']       = 'Buscar aquí...';
$_['text_category']     = 'Eliga una categoria';
$_['text_empty']        = 'Ups, No hay productos para mostrar en esta categoría';