<?php
$_['text_vertical_bar'] = 'All Cattegories';
$_['text_mobile_bar'] = 'Mobile Menu';
$_['text_more_item'] = '<i class="lnr lnr-plus-circle"></i> More Items';
$_['text_close_item'] = '<i class="lnr lnr-circle-minus"></i> Close Items';