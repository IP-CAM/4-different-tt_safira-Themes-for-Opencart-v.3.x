<?php
$_['text_vertical_bar'] = 'Categorias';
$_['text_mobile_bar'] = 'Menu';
$_['text_more_item'] = '<i class="lnr lnr-plus-circle"></i> Mas';
$_['text_close_item'] = '<i class="lnr lnr-circle-minus"></i> Cerrar';