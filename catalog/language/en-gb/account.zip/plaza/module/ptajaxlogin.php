<?php
// Heading
$_['title']  = 'Ingresar o Crear una cuenta';