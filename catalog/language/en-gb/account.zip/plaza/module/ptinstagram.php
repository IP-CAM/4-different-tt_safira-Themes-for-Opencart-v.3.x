<?php
// Heading
$_['heading_title']    = '# Llamaya Instagram';

// Text
$_['text_module']      = '';
$_['text_follow']      = 'Síguenos en Instagram';
$_['text_des']         = 'Mira las novedades';
$_['text_copyright']   = 'Instagram -- &copy; %s';
$_['text_error']       = 'El Server de Instagram no responde';