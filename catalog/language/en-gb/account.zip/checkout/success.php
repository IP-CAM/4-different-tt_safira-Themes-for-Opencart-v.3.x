<?php
$_['heading_title'] 	=  '¡Su orden ha sido puesta!';
$_['text_basket'] 	=  'Carrito de compras';
$_['text_checkout'] 	=  'Revisa';
$_['text_success'] 	=  'Éxito';
$_['text_customer'] 	=  '<p> ¡Su pedido se ha procesado correctamente! </p> <p> Puede ver su historial de pedidos visitando la página <a href="%s"> mi cuenta </a> y haciendo clic en <a href </p> <p> Si su compra tiene una descarga asociada, puede ir a la página <a href="%s"> descargas </a> de la cuenta para ver </p> <p> Por favor dirija cualquier pregunta que tenga al <a href="%s"> propietario de la tienda </a>. </p> <p> ¡Gracias por comprar con nosotros en línea! >';
$_['text_guest'] 	=  '<p> ¡Su pedido se ha procesado correctamente! </p> <p> Por favor dirija cualquier pregunta que tenga al <a href="%s"> propietario de la tienda </a>. </p> <p> Gracias por ¡Compra con nosotros en línea! </p>';
