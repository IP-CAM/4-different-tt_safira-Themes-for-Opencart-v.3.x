<?php
// Text
$_['text_home']          = 'Inicio';
// Edit by Plazathemes
$_['text_wishlist']      = '<span class="text-wishlist">Lista de favoritos</span> <span class="txt-count">%s</span>';
$_['text_header']      = 'Llego el otoño con 20% OFF. Usa el codigo “SALEFEDEAL20”';
$_['text_header_phone']      = 'Atención al cliente';
// End edit
$_['text_shopping_cart'] 	=  'Carrito de compras';
$_['text_category'] 	=  'Categorías';
$_['text_account'] 	=  'Mi cuenta';
$_['text_register'] 	=  'Registro';
$_['text_login'] 	=  'Ingresar';
$_['text_order'] 	=  'Historial de pedidos';
$_['text_transaction'] 	=  'Transacción';
$_['text_download'] 	=  'Descargas';
$_['text_logout'] 	=  'Cerrar sesión';
$_['text_checkout'] 	=  'Pagar';
$_['text_search'] 	=  'Buscar';
$_['text_all'] 	=  'Mostrar todo';
