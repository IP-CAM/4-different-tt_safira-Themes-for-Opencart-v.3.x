<?php
// Text
$_['text_upload']    = 'Your file was successfully uploaded!';

// Error
$_['error_filename'] = 'Filename must be between 3 and 64 characters!';
$_['error_filetype'] = 'Invalid file type!';
$_['error_upload']   = 'Upload required!';