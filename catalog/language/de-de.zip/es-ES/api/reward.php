<?php
$_['text_success'] 	=  'Éxito: ¡Se ha aplicado el descuento de puntos de recompensa!';
$_['error_permission'] 	=  'Advertencia: ¡No tiene permiso para acceder a la API!';
$_['error_reward'] 	=  'Advertencia: ¡Por favor ingrese la cantidad de puntos de recompensa para usar!';
$_['error_points'] 	=  'Advertencia: ¡No tienes puntos de recompensa %s!';
$_['error_maximum'] 	=  'Advertencia: ¡El máximo número de puntos que se pueden aplicar es %s!';
