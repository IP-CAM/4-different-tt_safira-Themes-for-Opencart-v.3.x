<?php
$_['text_subject'] 	=  ' %s - Comisión de Afiliados';
$_['text_received'] 	=  '¡Felicitaciones! Ha recibido un pago de comisión del programa de afiliados %s';
$_['text_amount'] 	=  'Has recibido:';
$_['text_total'] 	=  'Su cantidad total de comisión es ahora:';
