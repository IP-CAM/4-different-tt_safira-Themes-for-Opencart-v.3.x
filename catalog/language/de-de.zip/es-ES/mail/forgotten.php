<?php
$_['text_subject'] 	=  ' %s - Solicitud de restablecimiento de contraseña';
$_['text_greeting'] 	=  'Se solicitó una nueva contraseña para la cuenta de cliente de %s.';
$_['text_change'] 	=  'Para restablecer su contraseña, haga clic en el siguiente enlace:';
$_['text_ip'] 	=  'El IP utilizado para realizar esta solicitud fue:';
