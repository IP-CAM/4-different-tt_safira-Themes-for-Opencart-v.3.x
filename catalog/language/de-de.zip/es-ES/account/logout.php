<?php
$_['heading_title'] 	=  'Fin de sesión de cuenta';
$_['text_message'] 	=  '<p> Se ha desconectado su cuenta. Ahora es seguro dejar el ordenador. </p> <p> Su cesta de la compra se ha guardado, los elementos dentro de ella se restaurarán cada vez que vuelva a acceder a su cuenta. </p>';
$_['text_account'] 	=  'Cuenta';
$_['text_logout'] 	=  'Cerrar sesión';
