<?php
$_['heading_title'] 	=  'Boletín de suscripción';
$_['text_account'] 	=  'Cuenta';
$_['text_newsletter'] 	=  'Hoja informativa';
$_['text_success'] 	=  'Éxito: ¡La suscripción al boletín se ha actualizado correctamente!';
$_['entry_newsletter'] 	=  'Suscribir';
