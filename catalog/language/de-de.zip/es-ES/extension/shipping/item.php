<?php
// Text
$_['text_title']       = 'Per Item';
$_['text_description'] = 'Per Item Shipping Rate';