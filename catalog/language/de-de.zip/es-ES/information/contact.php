<?php
$_['heading_title'] 	=  'Contáctenos';
$_['text_location'] 	=  'nuestra ubicación';
$_['text_store'] 	=  'Nuestras Tiendas';
$_['text_contact'] 	=  'Formulario de contacto';
$_['text_address'] 	=  'Dirección';
$_['text_telephone'] 	=  'Teléfono';
$_['text_fax'] 	=  'Fax';
$_['text_open'] 	=  'Los horarios de apertura';
$_['text_comment'] 	=  'Comentarios';
$_['text_success'] 	=  '<p> Su consulta ha sido enviada correctamente al propietario de la tienda! </p>';
$_['entry_name'] 	=  'Tu nombre';
$_['entry_email'] 	=  'Dirección de correo electrónico';
$_['entry_enquiry'] 	=  'Investigación';
$_['email_subject'] 	=  'Consulta %s';
$_['error_name'] 	=  '¡El nombre debe tener entre 3 y 32 caracteres!';
$_['error_email'] 	=  '¡La dirección de correo electrónico no parece válida!';
$_['error_enquiry'] 	=  '¡La investigación debe tener entre 10 y 3000 caracteres!';
