<?php
$_['text_all'] 	=  'Mostrar todo';
