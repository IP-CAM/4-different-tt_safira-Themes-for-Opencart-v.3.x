<?php
// Text
$_['text_title']       = 'Flat Rate';
$_['text_description'] = 'Flat Shipping Rate';