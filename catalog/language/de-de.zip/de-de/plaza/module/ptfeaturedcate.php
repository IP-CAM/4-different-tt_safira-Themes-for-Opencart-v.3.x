<?php
$_['title'] = "Featured Categories";
$_['text_products'] = "products";