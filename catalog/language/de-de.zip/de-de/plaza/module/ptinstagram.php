<?php
// Heading
$_['heading_title']    = '# Pataku Instagram';

// Text
$_['text_module']      = '';
$_['text_follow']      = 'Follow us on Instagram';
$_['text_des']         = 'Lookbook Feed';
$_['text_copyright']   = 'Instagram -- &copy; %s';
$_['text_error']       = 'Server not found';