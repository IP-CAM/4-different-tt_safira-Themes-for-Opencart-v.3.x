<?php
// Text
// Edit text_items by Plazathemes
$_['text_items']     = '<span class="txt-count">%s</span> <span class="text-cart">%s</span>';
// End edit
$_['text_empty']     = 'Your shopping cart is empty!';
$_['text_cart']      = 'View Cart';
$_['text_checkout']  = 'Checkout';
$_['text_recurring'] = 'Payment Profile';
$_['text_qty'] = 'Qty: ';