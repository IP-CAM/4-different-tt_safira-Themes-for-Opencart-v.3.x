<?php
// Text
$_['text_placeholder_search']       = 'Search here...';
$_['text_category']     = 'Select a categories';
$_['text_empty']        = 'There are no products to list in this category.';