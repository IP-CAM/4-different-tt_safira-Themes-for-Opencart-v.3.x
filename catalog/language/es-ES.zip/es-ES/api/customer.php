<?php
$_['text_success'] 	=  'Ha modificado correctamente clientes';
$_['error_permission'] 	=  'Advertencia: ¡No tiene permiso para acceder a la API!';
$_['error_customer'] 	=  '¡Debe seleccionar un cliente!';
$_['error_firstname'] 	=  '¡El nombre completo debe tener entre 1 y 32 caracteres!';
$_['error_lastname'] 	=  '¡El apellido debe tener entre 1 y 32 caracteres!';
$_['error_email'] 	=  '¡La dirección de correo electrónico no parece válida!';
$_['error_telephone'] 	=  '¡El teléfono debe tener entre 3 y 32 caracteres!';
$_['error_custom_field'] 	=  'Se requiere %s!';
