<?php
$_['text_success'] 	=  'Éxito: ¡Has modificado órdenes!';
$_['error_permission'] 	=  'Advertencia: ¡No tiene permiso para acceder a la API!';
$_['error_customer'] 	=  'Advertencia: ¡Los detalles del cliente deben ser ajustados!';
$_['error_payment_address'] 	=  'Advertencia: Dirección de pago requerida!';
$_['error_payment_method'] 	=  'Advertencia: ¡Se requiere el método de pago!';
$_['error_no_payment'] 	=  'Advertencia: No hay opciones de pago disponibles!';
$_['error_shipping_address'] 	=  'Advertencia: Se requiere la dirección de envío!';
$_['error_shipping_method'] 	=  'Advertencia: Se requiere el método de envío!';
$_['error_no_shipping'] 	=  'Advertencia: No Opciones de envío están disponibles!';
$_['error_stock'] 	=  'Advertencia: ¡Los productos marcados con *** no están disponibles en la cantidad deseada o no están en stock!';
$_['error_minimum'] 	=  'Advertencia: ¡La cantidad mínima de pedido para %s es %s!';
$_['error_not_found'] 	=  'Advertencia: ¡No se pudo encontrar el pedido!';
