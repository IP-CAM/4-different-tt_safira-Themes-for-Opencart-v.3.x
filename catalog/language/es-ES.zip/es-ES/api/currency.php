<?php
$_['text_success'] 	=  'Éxito: ¡Su moneda ha cambiado!';
$_['error_permission'] 	=  'Advertencia: ¡No tiene permiso para acceder a la API!';
$_['error_currency'] 	=  'Advertencia: ¡El código de moneda no es válido!';
