<?php
$_['text_success'] 	=  'Éxito: ¡La sesión API se inició correctamente!';
$_['error_key'] 	=  'Advertencia: ¡Clave API incorrecta!';
$_['error_ip'] 	=  'Advertencia: ¡Tu IP %s no está autorizado a acceder a esta API!';
