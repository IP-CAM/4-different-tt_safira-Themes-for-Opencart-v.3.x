<?php
$_['text_currency'] 	=  'Moneda';
