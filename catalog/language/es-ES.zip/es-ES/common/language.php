<?php
$_['text_language'] 	=  'Idioma';
