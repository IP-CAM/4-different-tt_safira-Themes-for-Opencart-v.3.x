<?php
$_['text_information'] 	=  'Información';
$_['text_service'] 	=  'Servicio al cliente';
$_['text_extra'] 	=  'Extras';
$_['text_contact'] 	=  'Contáctenos';
$_['text_return'] 	=  'Devoluciones';
$_['text_sitemap'] 	=  'Mapa del sitio';
$_['text_manufacturer'] 	=  'Marcas';
$_['text_voucher'] 	=  'Certificados de regalo';
$_['text_affiliate'] 	=  'Afiliado';
$_['text_special'] 	=  'Especiales';
$_['text_account'] 	=  'Mi cuenta';
$_['text_order'] 	=  'Historial de pedidos';
$_['text_wishlist'] 	=  'Lista de deseos';
$_['text_newsletter'] 	=  'Hoja informativa';
$_['text_powered'] 	=  'Desarrollado por <a href="http://www.opencart.com"> OpenCart </a> <br /> %s & copy; S';
