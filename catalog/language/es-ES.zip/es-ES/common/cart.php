<?php
$_['text_items'] 	=  '% S artículo (s) - %s';
$_['text_empty'] 	=  '¡Su cesta está vacía!';
$_['text_cart'] 	=  'Ver Carro';
$_['text_checkout'] 	=  'Revisa';
$_['text_recurring'] 	=  'Perfil de pago';
