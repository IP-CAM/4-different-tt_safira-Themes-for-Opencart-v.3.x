<?php
$_['text_subject'] 	=  ' %s - Orden %s';
$_['text_received'] 	=  'Ha recibido una orden.';
$_['text_order_id'] 	=  'Solicitar ID:';
$_['text_date_added'] 	=  'Fecha Agregada:';
$_['text_order_status'] 	=  'Estado del pedido:';
$_['text_product'] 	=  'Productos';
$_['text_total'] 	=  'Totales';
$_['text_comment'] 	=  'Los comentarios para su pedido son:';
