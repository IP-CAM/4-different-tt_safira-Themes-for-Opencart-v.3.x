<?php
// Heading
$_['heading_title'] 	=  'Mi cuenta';
$_['text_account'] 	=  'Cuenta';
$_['text_my_account'] 	=  'Mi cuenta';
$_['text_my_orders'] 	=  'Mis ordenes'; 
$_['text_my_affiliate'] 	=  'Mi cuenta de afiliado';
$_['text_my_newsletter'] 	=  'Hoja informativa';
$_['text_edit'] 	=  'Editar la información de su cuenta';
$_['text_password'] 	=  'cambia tu contraseña';
$_['text_address'] 	=  'Modificar las entradas de la libreta de direcciones';
$_['text_credit_card'] 	=  'Gestionar Tarjetas de Crédito Guardadas';
$_['text_wishlist'] 	=  'Modifique su lista de deseos';
$_['text_order'] 	=  'Ver el historial de pedidos';
$_['text_download'] 	=  'Descargas';
$_['text_reward'] 	=  'Tus puntos de recompensa';
$_['text_return'] 	=  'Ver sus solicitudes de devolución';
$_['text_transaction'] 	=  'Sus Transacciones';
$_['text_newsletter'] 	=  'Suscribirse a la newsletter';
$_['text_recurring'] 	=  'Pagos recurrentes';
$_['text_transactions'] 	=  'Actas';
$_['text_affiliate_add'] 	=  'Registrarse para una cuenta de afiliado';
$_['text_affiliate_edit'] 	=  'Editar la información de su afiliado';
$_['text_tracking'] 	=  'Código personalizado de seguimiento de afiliados';