<?php
$_['heading_title'] 	=  'Sus Transacciones';
$_['column_date_added'] 	=  'Fecha Agregada';
$_['column_description'] 	=  'Descripción';
$_['column_amount'] 	=  'Cantidad ( %s)';
$_['text_account'] 	=  'Cuenta';
$_['text_transaction'] 	=  'Sus Transacciones';
$_['text_total'] 	=  'Tu saldo actual es:';
$_['text_empty'] 	=  '¡No tienes ninguna transacción!';
